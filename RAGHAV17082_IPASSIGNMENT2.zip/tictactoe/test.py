import unittest
from a import validmove
from a import win
from a import validBoard

def check_valid_move():
	tile1= 1	   
	tile2= 0
	tile3= 0
	tile4= 2
	tile5= 1
	tile6= 2
	tile7= 1
	tile8= 0
	tile9= 2
	assert (validmove(1)==False), "Invalid move"
	assert (validmove(2)==False), "Invalid move"
	assert (validmove(3)==False), "Invalid move"
	assert (validmove(4)==False), "Invalid move"
	assert (validmove(5)==False), "Invalid move"
	assert (validmove(6)==False), "Invalid move"
	assert (validmove(7)==False), "Invalid move"
	assert (validmove(8)==False), "Invalid move"
	assert (validmove(9)==False), "Invalid move"

def check_win():
	tile1= 1	   
	tile2= 0
	tile3= 0
	tile4= 2
	tile5= 1
	tile6= 2
	tile7= 1
	tile8= 0
	tile9= 1
	assert (win()==True), "Game lost"

def check_valid_board():
	tile1= 1	   
	tile2= 2
	tile3= 1
	tile4= 2
	tile5= 1
	tile6= 2
	tile7= 1
	tile8= 2
	tile9= 1
	assert (validBoard()==True), "Board invalid"	

if __name__ == '__main__':
	check_valid_move()
	check_win()
	check_valid_board()
